# Evidence index

The numbered screenshots preserve the implementation history. Use the later execution and final-state evidence when assessing completion.

| Evidence | Meaning |
| --- | --- |
| 01–06 | Initial table/report/dashboard configuration. `02-import-upload-prepared.png` records the original blocked local file selection; `06-dashboard-awaiting-import.png` shows the dashboard before data was loaded. These do not establish successful imports. |
| 07 | Approved synthetic baseline CSV published to GitHub. |
| 08–14 | Successful staging load; baseline, delta and repeat target transforms; map/coalesce; final employee data; populated dashboard. |
| 15–17 | SkillWallet Review status and the ordered final employee list. The platform state is 90% with tasks in Review, not final approval. |
| 18 | Published project README visible in the repository. |

The blocked local-file path was resolved through the approved CSV/HTTPS data-source workflow. All three target transforms report zero errors; the repeated delta inserted zero records.

[Final target validation](final-target-validation.md) confirms 17 records, 17 unique Employee IDs, and 85/85 exact field matches. The [runbook](../docs/project-runbook.md) links individual screenshots and records the measured run counts. Full documentation, workbooks and evidence are included in this package.


Screenshots 19–22, captured 2026-09-30, recheck the current populated dashboard, Transform Map settings, five field mappings with Employee ID coalesce, and the three recorded histories. These rechecks do not represent additional import runs.


## Historical Excel replay — 3 October 2026

Screenshots 23–34 show the first XLSX replay against 17 existing project records. Read [xlsx-verification.md](xlsx-verification.md) for TH0001004–TH0001006. Its captured record IDs preceded the later target reset.


## Final Excel sequence from an empty target — 3 October 2026

Screenshots 35–47 show the empty target, baseline and delta file selection, staging, TH0001007 with 15 inserts, TH0001008 with 2 inserts and 2 updates, TH0001009 with 4 ignored rows, final 17 records, dashboard and mapping. Read [strict-xlsx-verification.md](strict-xlsx-verification.md). The baseline matched 75/75 workbook values; delta and repeat matched 85/85 expected values. All 15 baseline record IDs were retained by the delta and all 17 delta IDs by the repeat. The final-target files now describe this sequence. The original CSV snapshots are preserved in historical-csv-2026-09-29/. All four local preparation checks passed, bringing the report to 23 passed checks. Human signatures, genuine sprint records and reviewer acceptance remain separate requirements. Private backup and working files are excluded.


## Native Google Sheets and exports — 3 October 2026

Screenshots 48 and 49 show the native baseline and delta Sheets. Read [native-sheets-verification.md](native-sheets-verification.md). Native readback and Google XLSX exports matched all 95 data cells and both header rows. Sheets remain owner-only, with no permission changes. Verified exports are in data/google-sheets-export/ within the package; the original imported workbooks remain unchanged.
