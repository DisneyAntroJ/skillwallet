# Google Sheets Excel exports

These two XLSX files were exported from the owner-only native Google Sheets created on 3 October 2026. Both header rows and all 95 data cells match the original workbooks. They are additional provenance artifacts. The files actually used in the recorded ServiceNow imports remain one folder above, unchanged. See [native-sheets-verification.md](../../evidence/native-sheets-verification.md) for Sheet links, verification and access details.
